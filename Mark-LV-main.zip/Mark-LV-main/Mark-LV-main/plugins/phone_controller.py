import subprocess
import time
import json
import os
import re
import urllib.parse

CONTACTS_FILE = os.path.join(os.path.dirname(__file__), "contacts.json")
DEFAULT_PIN = "4747"

def load_contacts():
    if os.path.exists(CONTACTS_FILE):
        try:
            with open(CONTACTS_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_contacts(contacts):
    with open(CONTACTS_FILE, "w") as f:
        json.dump(contacts, f, indent=4)

PLUGIN = {
    "name": "control_android_phone",
    "description": (
        "Controls the user's Android phone wirelessly via ADB. "
        "Capabilities: unlock screen with PIN, open specific YouTube videos/searches, "
        "send direct WhatsApp messages automatically, open apps like Chess, type text, "
        "save contacts, place calls, and tap UI coordinates."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "Action to perform: 'unlock', 'wake', 'sleep', 'home', 'back', "
                    "'open_app', 'whatsapp', 'youtube', 'call', 'dial', 'add_contact', 'type', 'tap', 'volume_up', 'volume_down'."
                )
            },
            "target": {
                "type": "STRING",
                "description": "Contact name (e.g. 'Mom') or raw phone number to call/message."
            },
            "app_name": {
                "type": "STRING",
                "description": "Name of the app to open."
            },
            "text": {
                "type": "STRING",
                "description": "Message text for WhatsApp, search query for YouTube, X/Y coordinates for tap, or text to type."
            },
            "phone_number": {
                "type": "STRING",
                "description": "Optional direct phone number string."
            }
        },
        "required": ["action"]
    }
}

TOOL = PLUGIN

APP_PACKAGES = {
    "instagram": "com.instagram.android",
    "chrome": "com.android.chrome",
    "browser": "com.android.chrome",
    "spotify": "com.spotify.music",
    "settings": "com.android.settings",
    "maps": "com.google.android.apps.maps",
    "camera": "android.media.action.STILL_IMAGE_CAMERA",
    "chess": "com.chess",
    "lichess": "org.lichess.mobileapp"
}

def resolve_number(target: str) -> str:
    if not target:
        return ""
    contacts = load_contacts()
    clean_target = target.lower().strip()
    for name, number in contacts.items():
        if name.lower() == clean_target or clean_target in name.lower():
            return number
    raw_digits = re.sub(r"[^\d+]", "", target)
    if len(raw_digits) >= 3:
        return raw_digits
    return ""

def launch_app(app_name: str) -> str:
    subprocess.run("adb shell input keyevent 224", shell=True)
    app_key = app_name.lower().strip()
    
    if app_key == "camera":
        cmd = "adb shell am start -a android.media.action.STILL_IMAGE_CAMERA"
    elif app_key in APP_PACKAGES:
        pkg = APP_PACKAGES[app_key]
        cmd = f"adb shell monkey -p {pkg} -c android.intent.category.LAUNCHER 1"
    else:
        cmd = f"adb shell monkey -p {app_key} 1"
        
    subprocess.run(cmd, shell=True)
    return f"Opened {app_name} on your phone, sir."

def run(*args, **kwargs):
    params = {}
    if args:
        if isinstance(args[0], dict):
            params.update(args[0])
        elif isinstance(args[0], str):
            params["action"] = args[0]
    if kwargs:
        params.update(kwargs)

    action = str(params.get("action", "unlock")).lower().strip()
    target = str(params.get("target", "")).strip()
    app_name = str(params.get("app_name", "")).strip()
    text = str(params.get("text", "")).strip()
    phone_number = str(params.get("phone_number", "")).strip()

    # Route raw app names
    if action.startswith("open_"):
        candidate = action.replace("open_", "").strip()
        if candidate in APP_PACKAGES:
            app_name = candidate
            action = "open_app"
    elif action in APP_PACKAGES:
        app_name = action
        action = "open_app"

    # 1. Unlock screen (Wake + Swipe Up + PIN)
    if any(k in action for k in ["unlock", "open_phone"]):
        subprocess.run("adb shell input keyevent 224", shell=True)
        time.sleep(0.3)
        # Swipe up to reveal the PIN pad
        subprocess.run("adb shell input swipe 500 1600 500 400 250", shell=True)
        time.sleep(0.4)
        # Enter the 4-digit PIN
        subprocess.run(f"adb shell input text {DEFAULT_PIN}", shell=True)
        time.sleep(0.2)
        # Hit Enter to submit
        subprocess.run("adb shell input keyevent 66", shell=True)
        return f"Phone unlocked with PIN {DEFAULT_PIN}."

    # 2. WhatsApp Direct Messaging
    if action == "whatsapp":
        lookup = phone_number or target
        resolved = resolve_number(lookup)
        if not resolved or not text:
            return "Please provide both a contact name and a message to send on WhatsApp."
        
        encoded_text = urllib.parse.quote(text)
        subprocess.run("adb shell input keyevent 26", shell=True)
        time.sleep(0.3)
        subprocess.run("adb shell input swipe 500 1600 500 400 250", shell=True)
        time.sleep(0.4)
        subprocess.run(f"adb shell input text {DEFAULT_PIN}", shell=True)
        time.sleep(0.2)
        subprocess.run("adb shell input keyevent 66", shell=True)
        time.sleep(0.5)

        cmd = f'adb shell am start -a android.intent.action.VIEW -d "https://api.whatsapp.com/send?phone={resolved}&text={encoded_text}"'
        subprocess.run(cmd, shell=True)
        time.sleep(1.5)
        
        # Tap the send button (general bottom right coordinate) or fallback to Enter
        subprocess.run("adb shell input tap 980 2200", shell=True)
        subprocess.run("adb shell input keyevent 66", shell=True)
        return f"Sent WhatsApp message to {lookup}."

    # 3. YouTube Deep Search
    if action == "youtube":
        subprocess.run("adb shell input keyevent 224", shell=True)
        if text:
            encoded_query = urllib.parse.quote(text)
            cmd = f'adb shell am start -a android.intent.action.VIEW -d "vnd.youtube://www.youtube.com/results?search_query={encoded_query}"'
            subprocess.run(cmd, shell=True)
            return f"Searched YouTube for '{text}'."
        else:
            subprocess.run("adb shell monkey -p com.google.android.youtube -c android.intent.category.LAUNCHER 1", shell=True)
            return "Opened YouTube homepage."

    # 4. Add Contact
    if action == "add_contact":
        contact_name = target or app_name
        contact_number = text or phone_number
        contacts = load_contacts()
        clean_num = re.sub(r"[^\d+]", "", contact_number)
        contacts[contact_name] = clean_num
        save_contacts(contacts)
        return f"Saved contact '{contact_name}'."

    # 5. Call / Dial
    if action in ["call", "dial"]:
        lookup = phone_number or target or text
        resolved = resolve_number(lookup)
        if not resolved:
            return f"No phone number found for '{lookup}'."
        subprocess.run("adb shell input keyevent 224", shell=True)
        time.sleep(0.2)
        subprocess.run(f"adb shell am start -a android.intent.action.DIAL -d tel:{resolved}", shell=True)
        time.sleep(1.0)
        if action == "call":
            subprocess.run("adb shell input keyevent 5", shell=True)
        return f"Called {lookup}."

    # 6. Open App
    if action == "open_app" or app_name:
        return launch_app(app_name or target)

    # 7. Type / Tap
    if action == "type":
        formatted = text.replace(" ", "%s").replace('"', '\\"')
        subprocess.run(f'adb shell input text "{formatted}"', shell=True)
        return f"Typed '{text}'."
    
    if action == "tap":
        coords = text.split()
        if len(coords) == 2:
            subprocess.run(f"adb shell input tap {coords[0]} {coords[1]}", shell=True)
            return f"Tapped screen at {coords[0]}, {coords[1]}."

    # 8. Hardware Buttons
    commands = {
        "wake": "adb shell input keyevent 224",
        "sleep": "adb shell input keyevent 26",
        "home": "adb shell input keyevent 3",
        "back": "adb shell input keyevent 4",
        "volume_up": "adb shell input keyevent 24",
        "volume_down": "adb shell input keyevent 25"
    }
    if action in commands:
        subprocess.run(commands[action], shell=True)
        return f"Executed {action}."

    return f"Unsupported action: {action}"

handler = run