import os

PLUGIN = {
    "name": "study_vault",
    "description": (
        "Saves or retrieves permanent study notes for specific subjects. "
        "Call this to save a session summary, or to load a previous subject's notes before a new lesson."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'save' or 'load'"
            },
            "subject": {
                "type": "STRING",
                "description": "The subject name (e.g., 'Geography', 'Physics', 'English')"
            },
            "content": {
                "type": "STRING",
                "description": "The detailed notes to save. Leave empty if loading."
            }
        },
        "required": ["action", "subject"]
    }
}

TOOL = PLUGIN
VAULT_DIR = os.path.join(os.path.dirname(__file__), "..", "memory", "vault")

def run(*args, **kwargs):
    params = {}
    if args:
        if isinstance(args[0], dict):
            params.update(args[0])
    if kwargs:
        params.update(kwargs)

    action = str(params.get("action", "")).lower().strip()
    subject = str(params.get("subject", "general")).lower().strip()
    content = str(params.get("content", "")).strip()

    if not os.path.exists(VAULT_DIR):
        os.makedirs(VAULT_DIR)

    file_path = os.path.join(VAULT_DIR, f"{subject}_journal.txt")

    if action == "save":
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(content + "\n\n")
        return f"Notes permanently archived in the {subject.capitalize()} vault."

    elif action == "load":
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                notes = f.read()
            return f"VAULT ARCHIVE FOR {subject.upper()}:\n{notes}\n\n(Review this data to restore your context on the subject.)"
        else:
            return f"No prior archives found for {subject.capitalize()}."

    return "Specify 'save' or 'load' action."

handler = run