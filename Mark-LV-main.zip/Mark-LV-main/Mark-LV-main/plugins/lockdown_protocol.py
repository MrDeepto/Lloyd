import subprocess
import os
import sys

PLUGIN = {
    "name": "lockdown_protocol",
    "description": (
        "Secures the PC screen by launching a full-screen, unclosable black overlay. "
        "Use action='lock' when Deepto says he is leaving or wants to lock the system. "
        "Use action='unlock' to remove the overlay ONLY when Deepto returns and speaks the correct authorization code."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'lock' or 'unlock'"
            }
        },
        "required": ["action"]
    }
}

TOOL = PLUGIN

FLAG_FILE = os.path.join(os.path.dirname(__file__), "unlock.flag")
SCRIPT_FILE = os.path.join(os.path.dirname(__file__), "kiosk_overlay.pyw")

def _create_kiosk_script():
    # We removed the f-string formatting. The script now calculates its own path natively.
    script_content = """import tkinter as tk
import os

# Compute flag path dynamically so backslashes never break it
FLAG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "unlock.flag")

def check_unlock():
    if os.path.exists(FLAG_FILE):
        root.destroy()
    else:
        root.lift()
        root.attributes('-topmost', True)
        root.after(200, check_unlock)

def disable_event():
    pass

typed_buffer = ""

def ghost_key_listener(event):
    global typed_buffer
    if event.char:
        typed_buffer += event.char.lower()
    if len(typed_buffer) > 20:
        typed_buffer = typed_buffer[-20:]
    
    # If the user types the silent backdoor code
    if "kira" in typed_buffer:
        # Create the flag file via the keyboard so the system syncs
        with open(FLAG_FILE, "w") as f:
            f.write("keyboard_unlock")
        root.destroy()

root = tk.Tk()
root.attributes('-fullscreen', True)
root.attributes('-topmost', True)
root.configure(bg='black')

root.protocol("WM_DELETE_WINDOW", disable_event)
root.bind("<Key>", ghost_key_listener)

label = tk.Label(root, text="SYSTEM LOCKED\\nAWAITING AUTHORIZATION", fg="red", bg="black", font=("Courier", 24, "bold"))
label.pack(expand=True)

root.after(200, check_unlock)
root.mainloop()
"""
    with open(SCRIPT_FILE, "w") as f:
        f.write(script_content)

def run(*args, **kwargs):
    params = {}
    if args:
        if isinstance(args[0], dict):
            params.update(args[0])
        elif isinstance(args[0], str):
            params["action"] = args[0]
    if kwargs:
        params.update(kwargs)

    action = str(params.get("action", "")).lower().strip()

    if action == "lock":
        if os.path.exists(FLAG_FILE):
            os.remove(FLAG_FILE)
        
        _create_kiosk_script()
        
        CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
        subprocess.Popen([sys.executable, SCRIPT_FILE], creationflags=CREATE_NO_WINDOW)
        return "Lockdown activated. Screen overlay deployed. I am waiting for the authorization code."

    elif action == "unlock":
        with open(FLAG_FILE, "w") as f:
            f.write("unlock")
        return "Authorization accepted. Lockdown deactivated. Screen restored."

    return f"Unsupported action: {action}"

handler = run