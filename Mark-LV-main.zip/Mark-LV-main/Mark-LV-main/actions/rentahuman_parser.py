from playwright.sync_api import sync_playwright
import json

def parse_form(url: str) -> str:
    try:
        with sync_playwright() as p:
            # Launch a lightweight headless browser
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url)
            
            # Look for the Apply button and click it to open the modal
            try:
                apply_btn = page.locator("button", has_text="Apply")
                if apply_btn.count() > 0:
                    apply_btn.first.click(timeout=3000)
            except Exception:
                pass # Modal might already be open
            
            # Wait a second for the dynamic modal to render
            page.wait_for_timeout(1000)
            
            fields = []
            # Scrape every input box and text area
            elements = page.locator("input, textarea").all()
            
            for el in elements:
                if el.is_visible():
                    tag = el.evaluate("el => el.tagName.toLowerCase()")
                    el_id = el.get_attribute("id") or "no_id"
                    name = el.get_attribute("name") or "no_name"
                    el_type = el.get_attribute("type") or "text"
                    
                    # Try to grab the exact question/label for this box
                    label_text = ""
                    if el_id != "no_id":
                        label = page.locator(f"label[for='{el_id}']")
                        if label.count() > 0:
                            label_text = label.first.inner_text()
                    
                    fields.append({
                        "tag": tag,
                        "type": el_type,
                        "id": el_id,
                        "name": name,
                        "question": label_text.strip()
                    })
            
            browser.close()
            
            if not fields:
                return "No form fields detected. The page might require a manual login first."
            
            return json.dumps(fields, indent=2)
            
    except Exception as e:
        return f"Parser error: {str(e)}"

def form_parser_controller(parameters: dict = None, **kwargs) -> str:
    params = parameters or {}
    url = params.get("url")
    if not url:
        return "Error: I need the exact URL of the bounty page."
    return parse_form(url)

# ── Tool declaration for Lloyd's auto-discovery ──────────────
TOOL = {
    "name": "parse_rentahuman_form",
    "description": "Scrapes a bounty page to extract the exact questions and IDs of the application form fields.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "url": {
                "type": "STRING",
                "description": "The URL of the RentAHuman bounty page."
            }
        },
        "required": ["url"]
    },
    "handler": form_parser_controller,
}