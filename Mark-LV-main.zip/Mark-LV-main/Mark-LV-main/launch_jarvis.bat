@echo off
cd /d "%~dp0"
python main.py
pause
cd /d "U:\Mark-LV-main\Mark-LV-main"
py -3.13 main.py